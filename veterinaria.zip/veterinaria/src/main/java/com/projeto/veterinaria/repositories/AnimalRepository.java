package com.projeto.veterinaria.repositories;

public interface AnimalRepository {

}
