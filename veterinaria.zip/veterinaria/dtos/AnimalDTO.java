package com.projeto.veterinaria.dtos;

public class AnimalDTO {
	
	private Long idAnimal;
	private String nomeAnimal;
	private String especieAnimal;
	
	public Long getIdAnimal() {
		return idAnimal;
	}
	public void setIdAnimal(Long idAnimal) {
		this.idAnimal = idAnimal;
	}
	public String getNomeAnimal() {
		return nomeAnimal;
	}
	public void setNomeAnimal(String nomeAnimal) {
		this.nomeAnimal = nomeAnimal;
	}
	public String getEspecieAnimal() {
		return especieAnimal;
	}
	public void setEspecieAnimal(String especieAnimal) {
		this.especieAnimal = especieAnimal;
	}
	
	

}
